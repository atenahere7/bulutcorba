import React, { useEffect, useMemo, useState } from "react"

// ÖRNEK MENÜ VERİSİ -----------------------------------------------------------
// İsterseniz bunu bir API'den fetch ederek de doldurabilirsiniz.
const MENU = [
  { id: "k1", category: "Kahvaltı", name: "Serpme Kahvaltı (2 Kişilik)", desc: "Peynir, zeytin, reçel, yumurta, simit…", price: 480, kcal: 950 },
  { id: "k2", category: "Kahvaltı", name: "Menemen", desc: "2 yumurtalı, domatesli, biberli", price: 140, kcal: 360 },
  { id: "k3", category: "Kahvaltı", name: "Omlet", desc: "Klasik, kaşarlı ya da mantarlı", price: 120, kcal: 310 },

  { id: "i1", category: "İçecekler", name: "Çay", desc: "İnce belli", price: 20, kcal: 2 },
  { id: "i2", category: "İçecekler", name: "Türk Kahvesi", desc: "Sade/Orta/Şekerli", price: 65, kcal: 5 },
  { id: "i3", category: "İçecekler", name: "Latte", desc: "Sıcak", price: 95, kcal: 180 },
  { id: "i4", category: "İçecekler", name: "Ayran", desc: "200 ml", price: 35, kcal: 60 },

  { id: "y1", category: "Yemekler", name: "Izgara Köfte", desc: "Pilav + salata", price: 260, kcal: 720 },
  { id: "y2", category: "Yemekler", name: "Tavuk Izgara", desc: "Sebzeli bulgur pilavı ile", price: 240, kcal: 640 },
  { id: "y3", category: "Yemekler", name: "Sebzeli Makarna", desc: "Kremalı", price: 190, kcal: 560 },

  { id: "t1", category: "Tatlılar", name: "Sütlaç", desc: "Fırınlanmış", price: 95, kcal: 290 },
  { id: "t2", category: "Tatlılar", name: "Tiramisu", desc: "Kakao serpiştirmeli", price: 120, kcal: 420 },
  { id: "t3", category: "Tatlılar", name: "Magnolia", desc: "Çilekli", price: 125, kcal: 410 },
];

const formatTRY = (v) =>
  new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(v);

const uniq = (arr) => Array.from(new Set(arr));

export default function App() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Tümü");
  const [cart, setCart] = useState({}); // { [id]: qty }
  const [drawerOpen, setDrawerOpen] = useState(false);

  // Masa numarası gibi QR parametresi (örn: ?table=5)
  const [table, setTable] = useState(null);
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const t = params.get("table");
    if (t) setTable(t);
  }, []);

  // localStorage kalıcılık
  useEffect(() => {
    try {
      const saved = localStorage.getItem("qrmenu_cart");
      if (saved) setCart(JSON.parse(saved));
    } catch {}
  }, []);
  useEffect(() => {
    try {
      localStorage.setItem("qrmenu_cart", JSON.stringify(cart));
    } catch {}
  }, [cart]);

  const categories = useMemo(() => ["Tümü", ...uniq(MENU.map((m) => m.category))], []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return MENU.filter((m) =>
      (category === "Tümü" || m.category === category) &&
      (q === "" || m.name.toLowerCase().includes(q) || (m.desc || "").toLowerCase().includes(q))
    );
  }, [query, category]);

  const cartItems = useMemo(() => {
    const items = Object.entries(cart).map(([id, qty]) => {
      const item = MENU.find((m) => m.id === id);
      return item ? { ...item, qty } : null;
    }).filter(Boolean);
    const total = items.reduce((acc, it) => acc + it.price * it.qty, 0);
    const count = items.reduce((acc, it) => acc + it.qty, 0);
    return { items, total, count };
  }, [cart]);

  const add = (id) => setCart((c) => ({ ...c, [id]: (c[id] || 0) + 1 }));
  const dec = (id) => setCart((c) => {
    const next = { ...c };
    if (!next[id]) return next;
    next[id] = next[id] - 1;
    if (next[id] <= 0) delete next[id];
    return next;
  });
  const removeLine = (id) => setCart((c) => {
    const n = { ...c };
    delete n[id];
    return n;
  });
  const clear = () => setCart({});

  const placeOrder = () => {
    if (cartItems.items.length === 0) return alert("Sepet boş!");
    const orderText = `Masa: ${table || "-"}\n` + cartItems.items.map(it => `• ${it.name} x${it.qty}`).join("\n") + `\nToplam: ${formatTRY(cartItems.total)}`;
    // WhatsApp entegrasyonu (numarayı değiştirin: 90XXXXXXXXXX)
    const phone = "90XXXXXXXXXX";
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(orderText)}`;
    window.open(url, "_blank");
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {/* ÜST BAR */}
      <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-gray-200">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400" />
            <div>
              <h1 className="text-lg font-semibold leading-tight">Örnek Restoran</h1>
              <p className="text-xs text-gray-500">Temassız Dijital Menü</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setDrawerOpen(true)}
              className="relative rounded-xl border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-100"
            >
              Sepet
              {cartItems.count > 0 && (
                <span className="ml-2 inline-flex items-center justify-center min-w-6 h-6 text-xs rounded-full bg-emerald-500 text-white px-1.5">
                  {cartItems.count}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* ARAMA + KATEGORİLER */}
      <section className="max-w-5xl mx-auto px-4 pt-4">
        <div className="flex flex-col gap-3">
          <input
            placeholder="Ara: ürün adı, açıklama…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full rounded-xl border border-gray-300 px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />

          <div className="no-scrollbar overflow-x-auto flex gap-2 pb-1">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={
                  "shrink-0 rounded-full border px-4 py-1.5 text-sm transition " +
                  (cat === category
                    ? "bg-emerald-500 text-white border-emerald-500"
                    : "border-gray-300 hover:bg-gray-100")
                }
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ÜRÜN LİSTESİ */}
      <main className="max-w-5xl mx-auto px-4 py-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((m) => (
          <article key={m.id} className="rounded-2xl bg-white border border-gray-200 shadow-sm hover:shadow transition">
            <div className="aspect-[4/3] rounded-t-2xl bg-gradient-to-br from-gray-200 to-gray-100 flex items-center justify-center text-gray-400">
              {/* Görselleriniz varsa burada <img src=... /> kullanabilirsiniz */}
              <span className="text-xs">Ürün görseli</span>
            </div>
            <div className="p-4 flex flex-col gap-2">
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-semibold leading-snug">{m.name}</h3>
                <span className="font-semibold text-emerald-600">{formatTRY(m.price)}</span>
              </div>
              {m.desc && <p className="text-sm text-gray-600 line-clamp-2">{m.desc}</p>}
              {m.kcal && (
                <p className="text-xs text-gray-400">~{m.kcal} kcal</p>
              )}
              <div className="pt-2">
                <button
                  onClick={() => add(m.id)}
                  className="w-full rounded-xl bg-emerald-500 text-white py-2 text-sm font-medium hover:bg-emerald-600"
                >
                  Sepete Ekle
                </button>
              </div>
            </div>
          </article>
        ))}
      </main>

      {/* ALT BANT: TOPLAM */}
      <footer className="sticky bottom-3 z-30">
        <div className="max-w-5xl mx-auto px-4">
          <div className="rounded-2xl bg-white/90 backdrop-blur border border-gray-200 shadow-lg p-3 flex items-center justify-between">
            <div className="text-sm text-gray-700">
              {cartItems.count > 0 ? (
                <>
                  <span className="font-medium">{cartItems.count} ürün</span>
                  <span className="mx-2">•</span>
                  <span className="font-semibold">{formatTRY(cartItems.total)}</span>
                </>
              ) : (
                <span>Sepetiniz boş</span>
              )}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setDrawerOpen(true)}
                className="rounded-xl border border-gray-300 px-4 py-2 text-sm hover:bg-gray-100"
              >
                Sepeti Görüntüle
              </button>
              <button
                onClick={placeOrder}
                className="rounded-xl bg-emerald-500 text-white px-4 py-2 text-sm font-medium hover:bg-emerald-600 disabled:opacity-50"
                disabled={cartItems.count === 0}
              >
                Sipariş Ver
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* SEPET ÇEKMECESİ */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/30" onClick={() => setDrawerOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-2xl flex flex-col">
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <h2 className="text-lg font-semibold">Sepet</h2>
              <button onClick={() => setDrawerOpen(false)} className="rounded-lg border px-3 py-1.5 text-sm">Kapat</button>
            </div>
            <div className="flex-1 overflow-auto p-4 flex flex-col gap-3">
              {cartItems.items.length === 0 && (
                <p className="text-sm text-gray-500">Sepetiniz boş. Ürün eklemek için listeden seçin.</p>
              )}
              {cartItems.items.map((it) => (
                <div key={it.id} className="border border-gray-200 rounded-xl p-3 flex items-center justify-between gap-3">
                  <div>
                    <div className="font-medium leading-tight">{it.name}</div>
                    <div className="text-xs text-gray-500">{formatTRY(it.price)} {it.kcal ? `• ~${it.kcal} kcal` : ""}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => dec(it.id)} className="h-8 w-8 rounded-lg border flex items-center justify-center text-lg">-</button>
                    <span className="min-w-6 text-center">{it.qty}</span>
                    <button onClick={() => add(it.id)} className="h-8 w-8 rounded-lg border flex items-center justify-center text-lg">+</button>
                    <button onClick={() => removeLine(it.id)} className="ml-2 text-xs text-red-600 underline">Kaldır</button>
                  </div>
                </div>
              ))}
            </div>
            <div className="p-4 border-t border-gray-200">
              <div className="flex items-center justify-between text-sm mb-3">
                <span>Ara Toplam</span>
                <span className="font-medium">{formatTRY(cartItems.total)}</span>
              </div>
              <button
                onClick={placeOrder}
                className="w-full rounded-xl bg-emerald-500 text-white py-2 text-sm font-medium hover:bg-emerald-600 disabled:opacity-50"
                disabled={cartItems.items.length === 0}
              >
                Sipariş Ver
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ALT KÜÇÜK YAZI */}
      <div className="max-w-5xl mx-auto px-4 py-12 text-center text-xs text-gray-400">
        <p>
          © {new Date().getFullYear()} Örnek Restoran. Bu sayfa demo amaçlıdır. Menü içerikleri temsilidir.
        </p>
      </div>
    </div>
  )
}
